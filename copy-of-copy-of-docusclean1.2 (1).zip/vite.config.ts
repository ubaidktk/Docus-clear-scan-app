import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  // FIX: Added base vite config for a React + Electron app.
  plugins: [react()],
  base: './', // Ensures relative paths are used for the Electron build.
})
