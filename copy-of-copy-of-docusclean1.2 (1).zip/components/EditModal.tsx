import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Page } from '../types';
import { CropIcon, ZoomInIcon, ZoomOutIcon, ResetZoomIcon } from './Icons';

interface EditModalProps {
  page: Page;
  onClose: () => void;
  onApply: (newSrc: string) => void;
  cropQueueIndex?: number;
  cropQueueTotal?: number;
}

type Point = { x: number; y: number };
type Corners = { tl: Point; tr: Point; br: Point; bl: Point };
type Handle = keyof Corners | 'tm' | 'rm' | 'bm' | 'lm';
type DragState = { handle: Handle; startCorners: Corners } | null;

const HANDLE_SIZE = 12; // Screen pixels
const HANDLE_COLOR = 'rgba(79, 70, 229, 1)'; // Indigo-600
const HANDLE_FILL_COLOR = 'rgba(255, 255, 255, 1)';
const LINE_COLOR = 'rgba(79, 70, 229, 0.9)';
const LOUPE_RADIUS = 75; // pixels
const LOUPE_ZOOM = 2.5;
const LOUPE_BORDER_WIDTH = 3;


// Helper function to solve a system of linear equations Ax = b using Gauss-Jordan elimination.
const solveLinSystem = (matrixA: number[][], vectorB: number[]): number[] | null => {
    const n = matrixA.length;
    const augmentedMatrix: number[][] = [];
    for (let i = 0; i < n; i++) {
        augmentedMatrix[i] = [...matrixA[i], vectorB[i]];
    }

    for (let i = 0; i < n; i++) {
        let maxEl = Math.abs(augmentedMatrix[i][i]);
        let maxRow = i;
        for (let k = i + 1; k < n; k++) {
            if (Math.abs(augmentedMatrix[k][i]) > maxEl) {
                maxEl = Math.abs(augmentedMatrix[k][i]);
                maxRow = k;
            }
        }

        [augmentedMatrix[i], augmentedMatrix[maxRow]] = [augmentedMatrix[maxRow], augmentedMatrix[i]];

        if (augmentedMatrix[i][i] === 0) return null; // No unique solution

        for (let k = i + 1; k < n; k++) {
            const c = -augmentedMatrix[k][i] / augmentedMatrix[i][i];
            for (let j = i; j < n + 1; j++) {
                if (i === j) {
                    augmentedMatrix[k][j] = 0;
                } else {
                    augmentedMatrix[k][j] += c * augmentedMatrix[i][j];
                }
            }
        }
    }

    const x = new Array(n).fill(0);
    for (let i = n - 1; i > -1; i--) {
        x[i] = augmentedMatrix[i][n] / augmentedMatrix[i][i];
        for (let k = i - 1; k > -1; k--) {
            augmentedMatrix[k][n] -= augmentedMatrix[k][i] * x[i];
        }
    }
    return x;
};


const EditModal: React.FC<EditModalProps> = ({ page, onClose, onApply, cropQueueIndex, cropQueueTotal }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [corners, setCorners] = useState<Corners | null>(null);
  const [dragState, setDragState] = useState<DragState>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<Point>({x: 0, y: 0});
  const [cropDimensions, setCropDimensions] = useState<{ w: number; h: number } | null>(null);
  const [loupe, setLoupe] = useState<{ active: boolean; pos: Point } | null>(null);
  
  const [viewTransform, setViewTransform] = useState({ zoom: 1, pan: { x: 0, y: 0 } });

  const getCanvasPoint = (e: React.MouseEvent<HTMLCanvasElement>): Point => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const canvasToImagePoint = useCallback((p: Point): Point => {
    const { zoom, pan } = viewTransform;
    return { x: (p.x - pan.x) / zoom, y: (p.y - pan.y) / zoom };
  }, [viewTransform]);

  const imageToCanvasPoint = useCallback((p: Point): Point => {
    const { zoom, pan } = viewTransform;
    return { x: p.x * zoom + pan.x, y: p.y * zoom + pan.y };
  }, [viewTransform]);

  const lerpPoint = (p1: Point, p2: Point, t: number): Point => ({
    x: p1.x + (p2.x - p1.x) * t,
    y: p1.y + (p2.y - p1.y) * t,
  });

  const dist = (p1: Point, p2: Point) => Math.hypot(p1.x - p2.x, p1.y - p2.y);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image?.complete || image.naturalWidth === 0 || !corners) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw image with pan/zoom
    ctx.drawImage(image, viewTransform.pan.x, viewTransform.pan.y, image.naturalWidth * viewTransform.zoom, image.naturalHeight * viewTransform.zoom);
    
    // Dark overlay
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(viewTransform.pan.x, viewTransform.pan.y, image.naturalWidth * viewTransform.zoom, image.naturalHeight * viewTransform.zoom);
    
    const canvasCorners = {
        tl: imageToCanvasPoint(corners.tl), tr: imageToCanvasPoint(corners.tr),
        br: imageToCanvasPoint(corners.br), bl: imageToCanvasPoint(corners.bl),
    };
    
    // Punch out the crop area from the overlay
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(canvasCorners.tl.x, canvasCorners.tl.y);
    ctx.lineTo(canvasCorners.tr.x, canvasCorners.tr.y);
    ctx.lineTo(canvasCorners.br.x, canvasCorners.br.y);
    ctx.lineTo(canvasCorners.bl.x, canvasCorners.bl.y);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(image, viewTransform.pan.x, viewTransform.pan.y, image.naturalWidth * viewTransform.zoom, image.naturalHeight * viewTransform.zoom);
    ctx.restore();

    // Draw crop border
    ctx.strokeStyle = LINE_COLOR;
    ctx.lineWidth = 2;
    ctx.stroke(new Path2D(`M${canvasCorners.tl.x},${canvasCorners.tl.y} L${canvasCorners.tr.x},${canvasCorners.tr.y} L${canvasCorners.br.x},${canvasCorners.br.y} L${canvasCorners.bl.x},${canvasCorners.bl.y} Z`));
    
    // Draw rule of thirds grid
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    const p1 = lerpPoint(canvasCorners.tl, canvasCorners.tr, 1/3); const p2 = lerpPoint(canvasCorners.tl, canvasCorners.tr, 2/3);
    const p3 = lerpPoint(canvasCorners.bl, canvasCorners.br, 1/3); const p4 = lerpPoint(canvasCorners.bl, canvasCorners.br, 2/3);
    const p5 = lerpPoint(canvasCorners.tl, canvasCorners.bl, 1/3); const p6 = lerpPoint(canvasCorners.tl, canvasCorners.bl, 2/3);
    const p7 = lerpPoint(canvasCorners.tr, canvasCorners.br, 1/3); const p8 = lerpPoint(canvasCorners.tr, canvasCorners.br, 2/3);
    ctx.stroke(new Path2D(`M${p1.x},${p1.y} L${p3.x},${p3.y}`)); ctx.stroke(new Path2D(`M${p2.x},${p2.y} L${p4.x},${p4.y}`));
    ctx.stroke(new Path2D(`M${p5.x},${p5.y} L${p7.x},${p7.y}`)); ctx.stroke(new Path2D(`M${p6.x},${p6.y} L${p8.x},${p8.y}`));

    // Draw handles
    const midpoints = {
        tm: lerpPoint(canvasCorners.tl, canvasCorners.tr, 0.5), rm: lerpPoint(canvasCorners.tr, canvasCorners.br, 0.5),
        bm: lerpPoint(canvasCorners.br, canvasCorners.bl, 0.5), lm: lerpPoint(canvasCorners.bl, canvasCorners.tl, 0.5),
    };
    [...Object.values(canvasCorners), ...Object.values(midpoints)].forEach(p => {
        ctx.fillStyle = HANDLE_FILL_COLOR;
        ctx.strokeStyle = HANDLE_COLOR;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(p.x, p.y, HANDLE_SIZE / 2, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
    });

    // Draw dimensions
    if (cropDimensions) {
        const text = `${Math.round(cropDimensions.w)} x ${Math.round(cropDimensions.h)}px`;
        ctx.font = '14px monospace';
        const textSize = ctx.measureText(text);
        const textPos = {
            x: canvasCorners.br.x - textSize.width - 20,
            y: canvasCorners.br.y - 20,
        };
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(textPos.x - 5, textPos.y - 15, textSize.width + 10, 20);
        ctx.fillStyle = 'white';
        ctx.fillText(text, textPos.x, textPos.y);
    }
    
    // Draw Loupe
    if (loupe?.active) {
        const { pos } = loupe;
        ctx.save();
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, LOUPE_RADIUS, 0, Math.PI * 2);
        ctx.strokeStyle = HANDLE_COLOR;
        ctx.lineWidth = LOUPE_BORDER_WIDTH;
        ctx.stroke();
        ctx.clip();
        
        ctx.fillStyle = 'black';
        ctx.fillRect(pos.x - LOUPE_RADIUS, pos.y - LOUPE_RADIUS, LOUPE_RADIUS * 2, LOUPE_RADIUS * 2);

        const imageP = canvasToImagePoint(pos);
        const sWidth = (LOUPE_RADIUS * 2) / viewTransform.zoom / LOUPE_ZOOM;
        const sHeight = sWidth;
        const sx = imageP.x - sWidth / 2;
        const sy = imageP.y - sHeight / 2;

        ctx.drawImage(image, sx, sy, sWidth, sHeight, 
            pos.x - LOUPE_RADIUS, pos.y - LOUPE_RADIUS, LOUPE_RADIUS * 2, LOUPE_RADIUS * 2);
        
        ctx.strokeStyle = 'rgba(255, 0, 0, 0.7)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(pos.x - 10, pos.y); ctx.lineTo(pos.x + 10, pos.y); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(pos.x, pos.y - 10); ctx.lineTo(pos.x, pos.y + 10); ctx.stroke();
        
        ctx.restore();
    }


  }, [corners, viewTransform, imageToCanvasPoint, cropDimensions, loupe, canvasToImagePoint]);

  const resetView = useCallback(() => {
    const image = imageRef.current;
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!image?.complete || !container || !canvas) return;
    
    const hRatio = container.clientWidth / image.naturalWidth;
    const vRatio = container.clientHeight / image.naturalHeight;
    const fitZoom = Math.min(hRatio, vRatio) * 0.9;
    
    setViewTransform({
        zoom: fitZoom,
        pan: {
            x: (container.clientWidth - image.naturalWidth * fitZoom) / 2,
            y: (container.clientHeight - image.naturalHeight * fitZoom) / 2
        }
    });
  }, []);

  useEffect(() => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.src = page.originalSrc;
    imageRef.current = image;

    const handleResize = () => {
        const canvas = canvasRef.current;
        const container = containerRef.current;
        if (canvas && container) {
            canvas.width = container.clientWidth;
            canvas.height = container.clientHeight;
            resetView();
        }
    };
    
    image.onload = () => {
        if (!corners) {
            setCorners({
              tl: { x: image.naturalWidth * 0.1, y: image.naturalHeight * 0.1 },
              tr: { x: image.naturalWidth * 0.9, y: image.naturalHeight * 0.1 },
              br: { x: image.naturalWidth * 0.9, y: image.naturalHeight * 0.9 },
              bl: { x: image.naturalWidth * 0.1, y: image.naturalHeight * 0.9 },
            });
        }
        handleResize();
    };

    const resizeObserver = new ResizeObserver(handleResize);
    if (containerRef.current) resizeObserver.observe(containerRef.current);
    return () => { if (containerRef.current) resizeObserver.unobserve(containerRef.current) };
  }, [page.originalSrc, resetView]);

  useEffect(draw, [draw]);

  const getHandleAtPoint = (p: Point): Handle | null => {
    if (!corners) return null;
    const canvasCorners = {
        tl: imageToCanvasPoint(corners.tl), tr: imageToCanvasPoint(corners.tr),
        br: imageToCanvasPoint(corners.br), bl: imageToCanvasPoint(corners.bl),
    };
     const midpoints = {
        tm: lerpPoint(canvasCorners.tl, canvasCorners.tr, 0.5), rm: lerpPoint(canvasCorners.tr, canvasCorners.br, 0.5),
        bm: lerpPoint(canvasCorners.br, canvasCorners.bl, 0.5), lm: lerpPoint(canvasCorners.bl, canvasCorners.tl, 0.5),
    };
    const handles = {...canvasCorners, ...midpoints};
    // Check corners first
    for (const key of ['tl', 'tr', 'br', 'bl']) {
        const handlePoint = handles[key as keyof typeof handles];
        if (dist(p, handlePoint) < HANDLE_SIZE) return key as Handle;
    }
    // Then check midpoints
    for (const key of ['tm', 'rm', 'bm', 'lm']) {
        const handlePoint = handles[key as keyof typeof handles];
        if (dist(p, handlePoint) < HANDLE_SIZE) return key as Handle;
    }
    return null;
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const p = getCanvasPoint(e);
    const handle = getHandleAtPoint(p);
    if (handle) {
        setDragState({ handle, startCorners: corners! });
        setLoupe({ active: true, pos: p });
    } else {
        setIsPanning(true);
        setPanStart({
            x: p.x - viewTransform.pan.x,
            y: p.y - viewTransform.pan.y
        });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const p = getCanvasPoint(e);
    if (dragState) {
      setLoupe({ active: true, pos: p });
      const imageP = canvasToImagePoint(p);
      const newCorners = JSON.parse(JSON.stringify(dragState.startCorners));
      
      if (['tl', 'tr', 'br', 'bl'].includes(dragState.handle)) {
          newCorners[dragState.handle as keyof Corners] = imageP;
      } else {
        let c1: keyof Corners | null = null, c2: keyof Corners | null = null;
        switch (dragState.handle) {
            case 'tm': c1 = 'tl'; c2 = 'tr'; break;
            case 'rm': c1 = 'tr'; c2 = 'br'; break;
            case 'bm': c1 = 'br'; c2 = 'bl'; break;
            case 'lm': c1 = 'bl'; c2 = 'tl'; break;
        }
        if (c1 && c2) {
            const startC1 = dragState.startCorners[c1];
            const startC2 = dragState.startCorners[c2];
            const edgeVec = { x: startC2.x - startC1.x, y: startC2.y - startC1.y };
            const edgeMagSq = edgeVec.x * edgeVec.x + edgeVec.y * edgeVec.y;
            
            if (edgeMagSq < 1) return; // Avoid division by zero for tiny edges
            
            const pointVec = { x: imageP.x - startC1.x, y: imageP.y - startC1.y };
            // FIX: Corrected the perpendicular distance calculation to prevent the edge from moving in the opposite direction of the drag.
            const perpDist = (pointVec.y * edgeVec.x - pointVec.x * edgeVec.y) / Math.sqrt(edgeMagSq);
            const normPerpVec = { x: -edgeVec.y / Math.sqrt(edgeMagSq), y: edgeVec.x / Math.sqrt(edgeMagSq) };
            
            newCorners[c1] = { x: startC1.x + normPerpVec.x * perpDist, y: startC1.y + normPerpVec.y * perpDist };
            newCorners[c2] = { x: startC2.x + normPerpVec.x * perpDist, y: startC2.y + normPerpVec.y * perpDist };
        }
      }
      setCorners(newCorners);
      setCropDimensions({
          w: Math.max(dist(newCorners.tl, newCorners.tr), dist(newCorners.bl, newCorners.br)),
          h: Math.max(dist(newCorners.tl, newCorners.bl), dist(newCorners.tr, newCorners.br))
      });

    } else if (isPanning) {
        setViewTransform(v => ({ ...v, pan: { x: p.x - panStart.x, y: p.y - panStart.y } }));
    } else {
        if (loupe?.active) setLoupe(null);
        const handle = getHandleAtPoint(p);
        e.currentTarget.style.cursor = handle ? 'pointer' : 'grab';
    }
  };

  const handleMouseUp = () => {
    setDragState(null);
    setIsPanning(false);
    setLoupe(null);
    setCropDimensions(null);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const p = getCanvasPoint(e as unknown as React.MouseEvent<HTMLCanvasElement>);
    const zoomFactor = 1.1;
    const newZoom = e.deltaY < 0 ? viewTransform.zoom * zoomFactor : viewTransform.zoom / zoomFactor;
    
    const imageP = canvasToImagePoint(p);
    const newPan = {
        x: p.x - imageP.x * newZoom,
        y: p.y - imageP.y * newZoom,
    };
    setViewTransform({ zoom: newZoom, pan: newPan });
  };
  
  const handleApply = () => {
    if (!corners || !imageRef.current) return;

    const dstWidth = Math.max(dist(corners.br, corners.bl), dist(corners.tr, corners.tl));
    const dstHeight = Math.max(dist(corners.tr, corners.br), dist(corners.tl, corners.bl));

    const srcPoints = [corners.tl, corners.tr, corners.br, corners.bl];
    const dstPoints = [ { x: 0, y: 0 }, { x: dstWidth, y: 0 }, { x: dstWidth, y: dstHeight }, { x: 0, y: dstHeight } ];

    const matrixA: number[][] = [];
    const vectorB: number[] = [];
    for (let i = 0; i < 4; i++) {
        const { x: sx, y: sy } = srcPoints[i];
        const { x: dx, y: dy } = dstPoints[i];
        matrixA.push([dx, dy, 1, 0, 0, 0, -sx * dx, -sx * dy]);
        vectorB.push(sx);
        matrixA.push([0, 0, 0, dx, dy, 1, -sy * dx, -sy * dy]);
        vectorB.push(sy);
    }
    
    const h = solveLinSystem(matrixA, vectorB);
    if (!h) { console.error("Could not solve for perspective transform."); return; }
    const [h11, h12, h13, h21, h22, h23, h31, h32] = h;
    
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = Math.round(dstWidth);
    tempCanvas.height = Math.round(dstHeight);
    const tempCtx = tempCanvas.getContext('2d')!;
    const dstImg = tempCtx.createImageData(tempCanvas.width, tempCanvas.height);

    const srcCanvas = document.createElement('canvas');
    srcCanvas.width = imageRef.current.naturalWidth;
    srcCanvas.height = imageRef.current.naturalHeight;
    const srcCtx = srcCanvas.getContext('2d')!;
    srcCtx.drawImage(imageRef.current, 0, 0);
    const srcImg = srcCtx.getImageData(0, 0, srcCanvas.width, srcCanvas.height);
    
    for (let y = 0; y < dstImg.height; y++) {
        for (let x = 0; x < dstImg.width; x++) {
            const denominator = h31 * x + h32 * y + 1;
            const srcX = (h11 * x + h12 * y + h13) / denominator;
            const srcY = (h21 * x + h22 * y + h23) / denominator;

            const x0 = Math.floor(srcX);
            const y0 = Math.floor(srcY);
            if (x0 < 0 || x0 >= srcImg.width - 1 || y0 < 0 || y0 >= srcImg.height - 1) continue;

            const dx = srcX - x0; const dy = srcY - y0;
            const getPixelIndex = (px: number, py: number) => (py * srcImg.width + px) * 4;
            const idx00 = getPixelIndex(x0, y0); const idx10 = getPixelIndex(x0 + 1, y0);
            const idx01 = getPixelIndex(x0, y0 + 1); const idx11 = getPixelIndex(x0 + 1, y0 + 1);
            const dstIdx = (y * dstImg.width + x) * 4;

            for (let i = 0; i < 4; i++) {
                const p00 = srcImg.data[idx00 + i]; const p10 = srcImg.data[idx10 + i];
                const p01 = srcImg.data[idx01 + i]; const p11 = srcImg.data[idx11 + i];
                const c0 = p00 * (1 - dx) + p10 * dx; const c1 = p01 * (1 - dx) + p11 * dx;
                dstImg.data[dstIdx + i] = c0 * (1 - dy) + c1 * dy;
            }
        }
    }
    tempCtx.putImageData(dstImg, 0, 0);
    onApply(tempCanvas.toDataURL('image/jpeg', 0.95));
  };
  
  const zoomBy = (factor: number) => {
    const canvas = canvasRef.current!;
    const center = { x: canvas.width / 2, y: canvas.height / 2 };
    const imageP = canvasToImagePoint(center);
    const newZoom = viewTransform.zoom * factor;
    const newPan = {
        x: center.x - imageP.x * newZoom,
        y: center.y - imageP.y * newZoom,
    };
    setViewTransform({ zoom: newZoom, pan: newPan });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex flex-col items-center justify-center z-50 p-4">
        <header className="w-full max-w-7xl bg-slate-800 p-3 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center gap-2">
                <CropIcon/>
                <h2 className="text-xl font-bold">Perspective Crop</h2>
            </div>
            {cropQueueTotal && cropQueueTotal > 1 && typeof cropQueueIndex === 'number' && (
                <span className="text-sm font-semibold text-slate-400">
                    Processing page {cropQueueIndex + 1} of {cropQueueTotal}
                </span>
            )}
        </header>
        <div ref={containerRef} className="flex-1 w-full max-w-7xl bg-slate-900 overflow-hidden relative">
            <canvas
                ref={canvasRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                onWheel={handleWheel}
            />
        </div>
        <footer className="w-full max-w-7xl bg-slate-800 p-3 rounded-b-lg flex justify-between items-center">
             <div className="flex items-center gap-2">
                <button onClick={() => zoomBy(1/1.2)} className="p-2 rounded hover:bg-slate-700"><ZoomOutIcon /></button>
                <span className="w-16 text-center text-sm font-mono">{Math.round(viewTransform.zoom*100)}%</span>
                <button onClick={() => zoomBy(1.2)} className="p-2 rounded hover:bg-slate-700"><ZoomInIcon /></button>
                <div className="border-l border-slate-600 h-6 mx-1"></div>
                <button onClick={resetView} className="p-2 rounded hover:bg-slate-700" title="Fit to view"><ResetZoomIcon /></button>
            </div>
            <div className="flex gap-4">
                <button onClick={onClose} className="px-4 py-2 bg-slate-600 rounded-md hover:bg-slate-700 transition">
                    Cancel
                </button>
                <button onClick={handleApply} className="px-4 py-2 bg-indigo-600 rounded-md hover:bg-indigo-700 transition">
                    {cropQueueTotal && cropQueueTotal > 1 ? 'Apply & Next' : 'Apply & Straighten'}
                </button>
            </div>
        </footer>
    </div>
  );
};

export default EditModal;