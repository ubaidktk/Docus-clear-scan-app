import React, { useState } from 'react';
import { Page, OcrData, FilterSettings } from '../types';
import {
    RotateIcon, OcrIcon, CopyIcon, ExportPdfIcon, ExportImageIcon, AutoFixIcon, BwIcon, 
    TextEnhanceIcon, ShadowRemovalIcon, CropIcon, ChevronDownIcon, ExportTxtIcon,
    BrightnessIcon, ContrastIcon, GrayscaleIcon, SharpenIcon, UndoIcon
} from './Icons';
import { extractTextFromImageLocal } from '../services/ocrService';
import { getFilteredImageData } from '../services/imageProcessor';
import { jsPDF } from 'jspdf';
import Spinner from './Spinner';

interface ControlsPanelProps {
    page: Page | null;
    selectedPages: Page[];
    onOcrDataUpdate: (data: OcrData) => void;
    pages: Page[];
    onSetEditMode: (mode: 'crop' | 'erase') => void;
    onApplyPreset: (preset: 'auto-enhance' | 'bw' | 'text-enhance' | 'shadow-remove') => void;
    onRotate: () => void;
    ocrLanguage: string;
    onOcrLanguageChange: (lang: string) => void;
    onFilterChange: (settings: Partial<FilterSettings>) => void;
    onApplySharpen: () => void;
}

const Accordion: React.FC<{ title: string; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);
    return (
        <div className="border-b border-slate-700">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center p-3 hover:bg-slate-700/50 focus:outline-none">
                <span className="font-semibold">{title}</span>
                <ChevronDownIcon className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && <div className="p-3">{children}</div>}
        </div>
    );
};

const ControlsPanel: React.FC<ControlsPanelProps> = ({
    page,
    selectedPages,
    onOcrDataUpdate,
    onSetEditMode,
    onApplyPreset,
    onRotate,
    ocrLanguage,
    onOcrLanguageChange,
    onFilterChange,
    onApplySharpen,
}) => {
    const [ocrStatus, setOcrStatus] = useState('');
    const [ocrError, setOcrError] = useState('');
    const [copySuccess, setCopySuccess] = useState('');
    const [isExporting, setIsExporting] = useState(false);
    
    const handleRunOcr = async () => {
        if (!page) return;
        setOcrStatus('Initializing...');
        setOcrError('');
        onOcrDataUpdate({ text: '', words: [], scaleFactor: 1 });
        try {
            const data = await extractTextFromImageLocal(page, ocrLanguage, (progress) => {
                 setOcrStatus(progress);
            });
            onOcrDataUpdate(data);
            setOcrStatus('');
        } catch (error) {
            setOcrError(error instanceof Error ? error.message : "An unknown OCR error occurred.");
            setOcrStatus('');
        }
    };

    const handleCopyToClipboard = () => {
        if (!page?.ocrData?.text) return;
        navigator.clipboard.writeText(page.ocrData.text).then(() => {
            setCopySuccess('Copied!');
            setTimeout(() => setCopySuccess(''), 2000);
        }, () => {
            setCopySuccess('Failed to copy');
            setTimeout(() => setCopySuccess(''), 2000);
        });
    };
    
    const handleExport = async (format: 'pdf' | 'jpeg' | 'png' | 'txt') => {
        if (selectedPages.length === 0) return;
        setIsExporting(true);
        
        try {
             if (format === 'pdf') {
                const doc = new jsPDF();
                for (let i = 0; i < selectedPages.length; i++) {
                    const p = selectedPages[i];
                    const imgData = await getFilteredImageData(p);
                    const img = new Image();
                    img.src = imgData;
                    await new Promise(resolve => { img.onload = resolve; });
                    
                    const pdfWidth = doc.internal.pageSize.getWidth();
                    const pdfHeight = doc.internal.pageSize.getHeight();
                    const ratio = Math.min(pdfWidth / img.width, pdfHeight / img.height);
                    const imgWidth = img.width * ratio;
                    const imgHeight = img.height * ratio;
                    const x = (pdfWidth - imgWidth) / 2;
                    const y = (pdfHeight - imgHeight) / 2;

                    if (i > 0) doc.addPage();
                    doc.addImage(imgData, 'JPEG', x, y, imgWidth, imgHeight);
                }
                doc.save("document.pdf");
            } else if (format === 'txt') {
                let combinedText = '';
                const pagesWithText = selectedPages.filter(p => p.ocrData && p.ocrData.text);
                if (pagesWithText.length === 0) return;
        
                pagesWithText.forEach((p, index) => {
                    if (pagesWithText.length > 1) {
                        combinedText += `--- ${p.name} ---\n\n`;
                    }
                    combinedText += p.ocrData!.text;
                    if (index < pagesWithText.length - 1) {
                        combinedText += '\n\n\n';
                    }
                });
        
                const blob = new Blob([combinedText], { type: 'text/plain;charset=utf-8' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                const fileName = selectedPages[0].name.replace(/\.[^/.]+$/, "") + `.txt`;
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);

            } else {
                for (const p of selectedPages) {
                    const imgData = await getFilteredImageData(p);
                    const link = document.createElement('a');
                    link.href = imgData;
                    const fileExtension = format === 'jpeg' ? 'jpg' : 'png';
                    const fileName = p.name.replace(/\.[^/.]+$/, "") + `.${fileExtension}`;
                    link.download = fileName;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            }
        } catch (error) {
            console.error("Export failed:", error);
        } finally {
            setIsExporting(false);
        }
    };

    if (selectedPages.length === 0) {
        return <aside className="w-80 bg-slate-800 border-l border-slate-700 p-4 text-slate-500">Select a page to see controls.</aside>;
    }
    
    const isRtl = ocrLanguage === 'urd';
    const firstSelected = selectedPages[0];
    const { brightness, contrast, grayscale } = firstSelected.filterSettings;

    return (
        <aside className="w-80 bg-slate-800 border-l border-slate-700 flex flex-col text-slate-200">
            <div className="flex-1 overflow-y-auto">
                <Accordion title="Presets" defaultOpen>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                        <button onClick={() => onApplyPreset('auto-enhance')} title="Auto Enhance (Ctrl+1)" className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><AutoFixIcon /> Auto Enhance</button>
                        <button onClick={() => onApplyPreset('bw')} title="B&W (Ctrl+2)" className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><BwIcon /> B&W</button>
                        <button onClick={() => onApplyPreset('text-enhance')} title="Text Enhance (Ctrl+3)" className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><TextEnhanceIcon /> Text Enhance</button>
                        <button onClick={() => onApplyPreset('shadow-remove')} title="Shadow Remove (Ctrl+4)" className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><ShadowRemovalIcon /> Shadow Remove</button>
                    </div>
                </Accordion>
                <Accordion title="Adjustments">
                    <div className="space-y-4 text-sm px-1">
                        <div>
                            <label className="flex justify-between items-center mb-1">
                                <span className="flex items-center gap-1.5"><BrightnessIcon /> Brightness</span>
                                <span className="font-mono bg-slate-700 px-1.5 py-0.5 rounded text-xs">{brightness}%</span>
                            </label>
                            <input type="range" min="0" max="200" value={brightness} onInput={(e) => onFilterChange({ brightness: (e.target as HTMLInputElement).valueAsNumber })} className="w-full h-1.5 bg-slate-600 rounded-lg appearance-none cursor-pointer range-thumb" />
                        </div>
                         <div>
                            <label className="flex justify-between items-center mb-1">
                                <span className="flex items-center gap-1.5"><ContrastIcon /> Contrast</span>
                                <span className="font-mono bg-slate-700 px-1.5 py-0.5 rounded text-xs">{contrast}%</span>
                            </label>
                            <input type="range" min="0" max="200" value={contrast} onInput={(e) => onFilterChange({ contrast: (e.target as HTMLInputElement).valueAsNumber })} className="w-full h-1.5 bg-slate-600 rounded-lg appearance-none cursor-pointer range-thumb" />
                        </div>
                         <div>
                            <label className="flex justify-between items-center mb-1">
                                <span className="flex items-center gap-1.5"><GrayscaleIcon /> Grayscale</span>
                                <span className="font-mono bg-slate-700 px-1.5 py-0.5 rounded text-xs">{grayscale}%</span>
                            </label>
                            <input type="range" min="0" max="100" value={grayscale} onInput={(e) => onFilterChange({ grayscale: (e.target as HTMLInputElement).valueAsNumber })} className="w-full h-1.5 bg-slate-600 rounded-lg appearance-none cursor-pointer range-thumb" />
                        </div>
                        <button onClick={onApplySharpen} className="w-full flex items-center justify-center gap-2 p-2 bg-slate-600 rounded-md hover:bg-slate-700 transition"><SharpenIcon /> Apply Sharpen</button>
                    </div>
                </Accordion>
                <Accordion title="Tools">
                     <div className="grid grid-cols-2 gap-2 text-sm">
                        <button onClick={onRotate} className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><RotateIcon /> Rotate</button>
                        <button onClick={() => onSetEditMode('crop')} className="flex flex-col items-center gap-1 p-2 rounded-md hover:bg-slate-700 transition"><CropIcon /> Crop</button>
                     </div>
                </Accordion>
                <Accordion title="Recognize Text (OCR)">
                    <div className="space-y-3">
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Language</label>
                            <div className="flex items-center justify-center p-1 rounded-md bg-slate-700">
                                <button onClick={() => onOcrLanguageChange('eng')} className={`w-1/2 py-1 text-sm rounded ${ocrLanguage === 'eng' ? 'bg-indigo-600' : 'hover:bg-slate-600'} transition`}>English</button>
                                <button onClick={() => onOcrLanguageChange('urd')} className={`w-1/2 py-1 text-sm rounded ${ocrLanguage === 'urd' ? 'bg-indigo-600' : 'hover:bg-slate-600'} transition`}>Urdu</button>
                            </div>
                        </div>
                         <button onClick={handleRunOcr} disabled={!!ocrStatus || !page || page.isIndexing} className="w-full flex items-center justify-center gap-2 p-2 bg-indigo-600 rounded-md hover:bg-indigo-700 transition disabled:opacity-50">
                            {ocrStatus ? <Spinner /> : (page?.isIndexing ? <Spinner /> : <OcrIcon />)}
                            {ocrStatus || (page?.isIndexing ? 'Indexing...' : 'Run OCR')}
                        </button>
                        {ocrError && <p className="text-xs text-red-400">{ocrError}</p>}
                        <div className="relative">
                            <textarea
                                value={page?.ocrData?.text || ''}
                                onChange={(e) => page && onOcrDataUpdate({ text: e.target.value, words: page.ocrData?.words || [], scaleFactor: page.ocrData?.scaleFactor || 1 })}
                                placeholder={ocrStatus ? '...' : 'OCR output will appear here...'}
                                dir={isRtl ? 'rtl' : 'ltr'}
                                className={`w-full h-40 bg-slate-900 rounded-md p-2 text-sm resize-none focus:ring-2 focus:ring-indigo-500 ${isRtl ? 'text-right' : 'text-left'}`}
                                disabled={!page}
                            />
                            {page?.ocrData?.text && !ocrStatus && (
                                <button onClick={handleCopyToClipboard} className="absolute top-2 right-2 p-1 rounded hover:bg-slate-700">
                                    <CopyIcon />
                                </button>
                            )}
                        </div>
                        {copySuccess && <p className="text-xs text-green-400 text-right">{copySuccess}</p>}
                    </div>
                </Accordion>
            </div>
             <div className="p-3 border-t border-slate-700">
                <h3 className="font-semibold mb-2">Export ({selectedPages.length} selected)</h3>
                <div className="grid grid-cols-3 gap-2">
                     <button onClick={() => handleExport('pdf')} disabled={isExporting || selectedPages.length === 0} className="w-full flex items-center justify-center gap-2 p-2 bg-slate-600 rounded-md hover:bg-slate-700 transition disabled:opacity-50">
                        {isExporting ? <Spinner/> : <ExportPdfIcon/>} PDF
                    </button>
                    <button onClick={() => handleExport('jpeg')} disabled={isExporting || selectedPages.length === 0} className="w-full flex items-center justify-center gap-2 p-2 bg-slate-600 rounded-md hover:bg-slate-700 transition disabled:opacity-50">
                        {isExporting ? <Spinner/> : <ExportImageIcon/>} JPG
                    </button>
                    <button onClick={() => handleExport('txt')} disabled={isExporting || selectedPages.filter(p => p.ocrData?.text).length === 0} className="w-full flex items-center justify-center gap-2 p-2 bg-slate-600 rounded-md hover:bg-slate-700 transition disabled:opacity-50 text-xs">
                        {isExporting ? <Spinner/> : <ExportTxtIcon/>} TXT
                    </button>
                </div>
            </div>
        </aside>
    );
};

export default ControlsPanel;