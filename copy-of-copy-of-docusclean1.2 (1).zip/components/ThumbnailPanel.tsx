
import React, { useState } from 'react';
import { Page, SearchResult, SearchMode } from '../types';
import { DeleteIcon, UploadIcon, DuplicateIcon, SearchIcon, ChevronDownIcon } from './Icons';
import Spinner from './Spinner';

interface ThumbnailPanelProps {
  pages: Page[];
  selectedPageIndex: number | null;
  onSelectPage: (index: number, isCtrl: boolean, isShift: boolean) => void;
  onDeletePage: (index: number) => void;
  onDuplicatePage: (index: number) => void;
  onRenamePage: (index: number, newName: string) => void;
  onAddPages: (files: File[]) => void;
  onReorderPages: (startIndex: number, endIndex: number) => void;
  searchTerm: string;
  onSearchTermChange: (term: string) => void;
  searchMode: SearchMode;
  onSearchModeChange: (mode: SearchMode) => void;
  searchResults: SearchResult[];
  currentSearchResultIndex: number | null;
  onNavigateSearch: (direction: 'next' | 'prev') => void;
  isIndexing: boolean;
}

const ThumbnailPanel: React.FC<ThumbnailPanelProps> = ({ 
    pages, 
    selectedPageIndex, 
    onSelectPage, 
    onDeletePage, 
    onDuplicatePage,
    onRenamePage,
    onAddPages, 
    onReorderPages,
    searchTerm,
    onSearchTermChange,
    searchMode,
    onSearchModeChange,
    searchResults,
    currentSearchResultIndex,
    onNavigateSearch,
    isIndexing
}) => {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [editingPageId, setEditingPageId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>, dropIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === dropIndex) return;
    onReorderPages(draggedIndex, dropIndex);
    setDraggedIndex(null);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onAddPages(Array.from(e.target.files));
      e.target.value = ''; 
    }
  };

  const handlePageClick = (e: React.MouseEvent, index: number) => {
    onSelectPage(index, e.ctrlKey || e.metaKey, e.shiftKey);
  };

  const handleStartEditingName = (e: React.MouseEvent, page: Page, index: number) => {
    e.stopPropagation();
    setEditingPageId(page.id);
    setEditingName(page.name);
  };

  const handleFinishEditingName = (index: number) => {
    if (editingPageId !== null && editingName.trim()) {
      onRenamePage(index, editingName.trim());
    }
    setEditingPageId(null);
    setEditingName('');
  };

  return (
    <nav className="w-64 bg-slate-800 border-r border-slate-700 p-2 flex flex-col">
      <div className="p-2 space-y-2">
        <div className="relative">
            <input 
                type="text" 
                placeholder={searchMode === 'name' ? "Search by name..." : "Search in documents..."}
                value={searchTerm}
                onChange={(e) => onSearchTermChange(e.target.value)}
                disabled={isIndexing}
                className="w-full bg-slate-700 p-2 pl-8 rounded text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none disabled:opacity-50"
            />
            <div className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400">
                <SearchIcon />
            </div>
        </div>
        <div className="flex items-center justify-center p-1 rounded-md bg-slate-700 text-xs">
            <button 
                onClick={() => onSearchModeChange('name')} 
                disabled={isIndexing}
                className={`w-1/2 py-1 rounded ${searchMode === 'name' ? 'bg-indigo-600' : 'hover:bg-slate-600'} transition disabled:opacity-50`}
            >
                Search by Name
            </button>
            <button 
                onClick={() => onSearchModeChange('deep')} 
                disabled={isIndexing}
                className={`w-1/2 py-1 rounded ${searchMode === 'deep' ? 'bg-indigo-600' : 'hover:bg-slate-600'} transition disabled:opacity-50`}
            >
                Deep Scan
            </button>
        </div>
        {searchMode === 'deep' && searchTerm && !isIndexing && (
            <div className="flex items-center justify-between text-sm text-slate-400">
                <span>{searchResults.length > 0 ? `Result ${currentSearchResultIndex! + 1} of ${searchResults.length}` : 'No results'}</span>
                <div className="flex gap-1">
                    <button onClick={() => onNavigateSearch('prev')} disabled={searchResults.length === 0} className="p-1 rounded hover:bg-slate-700 disabled:opacity-50"><ChevronDownIcon className="w-4 h-4 rotate-90" /></button>
                    <button onClick={() => onNavigateSearch('next')} disabled={searchResults.length === 0} className="p-1 rounded hover:bg-slate-700 disabled:opacity-50"><ChevronDownIcon className="w-4 h-4 -rotate-90" /></button>
                </div>
            </div>
        )}
      </div>
      <div className="flex-1 overflow-y-auto space-y-2 pr-1">
        {pages.map((page, index) => {
            const isVisible = searchMode === 'deep' || 
                (searchMode === 'name' && (!searchTerm || page.name.toLowerCase().includes(searchTerm.toLowerCase())));

            if (!isVisible) return null;

            return (
                <div
                    key={page.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, index)}
                    onClick={(e) => handlePageClick(e, index)}
                    className={`group relative p-1 rounded-md cursor-pointer border-2 ${
                    selectedPageIndex === index ? 'border-indigo-500' : 'border-transparent'
                    } ${
                    page.isSelected ? 'bg-slate-700' : 'hover:bg-slate-700/50'
                    } transition-all ${draggedIndex === index ? 'opacity-50' : ''}`}
                >
                    <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-400 w-6 text-center">{index + 1}</span>
                    <div className="relative w-16 h-16">
                        <img src={page.originalSrc} alt={page.name} className="w-full h-full object-cover rounded-md bg-slate-700" />
                        {page.isIndexing && (
                            <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center rounded-md">
                                <Spinner />
                            </div>
                        )}
                    </div>
                    <div className="text-xs flex-1 truncate" onDoubleClick={(e) => handleStartEditingName(e, page, index)}>
                        {editingPageId === page.id ? (
                        <input
                            type="text"
                            value={editingName}
                            onChange={(e) => setEditingName(e.target.value)}
                            onBlur={() => handleFinishEditingName(index)}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleFinishEditingName(index); if(e.key === 'Escape') setEditingPageId(null);}}
                            className="w-full bg-slate-900 rounded p-1"
                            autoFocus
                        />
                        ) : (
                        <p className="p-1" title={page.name}>{page.name}</p>
                        )}
                    </div>
                    </div>
                    <div className="absolute top-1 right-1 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                        onClick={(e) => { e.stopPropagation(); onDuplicatePage(index); }}
                        className="p-1 bg-blue-600 rounded-full text-white hover:bg-blue-700"
                        title="Duplicate Page"
                        >
                        <DuplicateIcon />
                        </button>
                        <button
                        onClick={(e) => { e.stopPropagation(); onDeletePage(index); }}
                        className="p-1 bg-red-600 rounded-full text-white hover:bg-red-700"
                        title="Delete Page (Delete)"
                        >
                        <DeleteIcon />
                        </button>
                    </div>
                </div>
            )
        })}
      </div>
      <div className="mt-2 pt-2 border-t border-slate-700">
        <input id="add-more-files" type="file" multiple accept="image/jpeg, image/png" onChange={handleFileChange} className="hidden" />
        <label htmlFor="add-more-files" className="w-full flex items-center justify-center gap-2 p-2 bg-slate-700 rounded-md hover:bg-slate-600 transition cursor-pointer">
            <UploadIcon /> Add Pages
        </label>
      </div>
    </nav>
  );
};

export default ThumbnailPanel;