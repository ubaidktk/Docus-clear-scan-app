import React, { useState, useEffect } from 'react';
import { getRecentDocuments, loadDocument, deleteDocument, RecentDocument } from '../services/storageService';
import { Page } from '../types';
import { CloseIcon, DeleteIcon } from './Icons';

interface RecentsManagerProps {
    onLoadDocument: (pages: Page[], dateKey: string) => void;
    onClose: () => void;
}

const RecentsManager: React.FC<RecentsManagerProps> = ({ onLoadDocument, onClose }) => {
    const [recents, setRecents] = useState<RecentDocument[]>([]);

    useEffect(() => {
        setRecents(getRecentDocuments());
    }, []);

    const handleLoad = (key: string) => {
        const pages = loadDocument(key);
        if (pages) {
            onLoadDocument(pages, key);
        }
    };

    const handleDelete = (key: string) => {
        if (window.confirm("Are you sure you want to delete this session? This action cannot be undone.")) {
            deleteDocument(key);
            setRecents(recents.filter(r => r.key !== key));
        }
    };

    const formatRelativeDate = (isoString: string) => {
        const date = new Date(isoString);
        const now = new Date();
        const diffSeconds = Math.round((now.getTime() - date.getTime()) / 1000);
        
        if (diffSeconds < 60) return `${diffSeconds}s ago`;
        const diffMinutes = Math.round(diffSeconds / 60);
        if (diffMinutes < 60) return `${diffMinutes}m ago`;
        const diffHours = Math.round(diffMinutes / 60);
        if (diffHours < 24) return `${diffHours}h ago`;
        
        return date.toLocaleDateString();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-slate-800 rounded-lg shadow-xl w-full max-w-2xl flex flex-col h-[70vh]">
                <header className="flex items-center justify-between p-4 border-b border-slate-700 flex-shrink-0">
                    <h2 className="text-xl font-bold">Recent Sessions</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-700">
                        <CloseIcon />
                    </button>
                </header>
                <main className="flex-1 overflow-y-auto p-4">
                    {recents.length === 0 ? (
                        <div className="flex items-center justify-center h-full text-slate-500">
                            <p>No recent sessions found.</p>
                        </div>
                    ) : (
                        <ul className="space-y-2">
                            {recents.map(doc => (
                                <li key={doc.key} className="group flex items-center justify-between p-3 bg-slate-700 rounded-md hover:bg-slate-600 transition cursor-pointer" onClick={() => handleLoad(doc.key)}>
                                    <div>
                                        <p className="font-semibold">{doc.name}</p>
                                        <p className="text-sm text-slate-400">
                                            {doc.pageCount} page(s) - Last modified {formatRelativeDate(doc.lastModified)}
                                        </p>
                                    </div>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handleDelete(doc.key);
                                        }}
                                        className="p-2 rounded-full text-slate-400 hover:bg-red-500 hover:text-white transition opacity-0 group-hover:opacity-100"
                                        title="Delete Session"
                                    >
                                        <DeleteIcon />
                                    </button>
                                </li>
                            ))}
                        </ul>
                    )}
                </main>
            </div>
        </div>
    );
};

export default RecentsManager;
