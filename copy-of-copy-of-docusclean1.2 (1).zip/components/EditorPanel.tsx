import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Page, SearchResult } from '../types';
import { ZoomInIcon, ZoomOutIcon, ResetZoomIcon } from './Icons';

interface EditorPanelProps {
  page: Page | null;
  selectedPageIndex: number | null;
  searchResults: SearchResult[];
  currentSearchResult: SearchResult | null;
}

type Point = { x: number; y: number };

const EditorPanel: React.FC<EditorPanelProps> = ({ page, selectedPageIndex, currentSearchResult }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [viewTransform, setViewTransform] = useState({ zoom: 1, pan: { x: 0, y: 0 } });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<Point>({x: 0, y: 0});
  
  const getCanvasPoint = (e: React.MouseEvent): Point => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const canvasToImagePoint = useCallback((p: Point): Point => {
    const { zoom, pan } = viewTransform;
    return { x: (p.x - pan.x) / zoom, y: (p.y - pan.y) / zoom };
  }, [viewTransform]);

  const resetView = useCallback(() => {
    const image = imageRef.current;
    const container = containerRef.current;
    // FIX: Add a guard to prevent calculating zoom on a zero-sized container, which was making the image invisible.
    if (!image?.complete || !container || image.naturalWidth === 0 || container.clientWidth === 0) return;
    
    const hRatio = container.clientWidth / image.naturalWidth;
    const vRatio = container.clientHeight / image.naturalHeight;
    const fitZoom = Math.min(hRatio, vRatio) * 0.95;
    
    setViewTransform({
        zoom: fitZoom,
        pan: {
            x: (container.clientWidth - image.naturalWidth * fitZoom) / 2,
            y: (container.clientHeight - image.naturalHeight * fitZoom) / 2
        }
    });
  }, []);
  
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!page || !image?.complete || image.naturalWidth === 0) return;
    
    // FIX: Apply live filters from filterSettings for real-time preview.
    const { brightness, contrast, grayscale } = page.filterSettings;
    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) grayscale(${grayscale}%)`;

    ctx.drawImage(image, viewTransform.pan.x, viewTransform.pan.y, image.naturalWidth * viewTransform.zoom, image.naturalHeight * viewTransform.zoom);
    
    // Reset filter before drawing overlays
    ctx.filter = 'none';

    if (currentSearchResult && page.ocrData && selectedPageIndex === currentSearchResult.pageIndex) {
        ctx.save();
        ctx.translate(viewTransform.pan.x, viewTransform.pan.y);
        ctx.scale(viewTransform.zoom, viewTransform.zoom);

        const scaleFactor = page.ocrData.scaleFactor || 1;
        ctx.fillStyle = 'rgba(255, 255, 0, 0.4)'; // Yellow highlight

        currentSearchResult.wordMatches.forEach(match => {
            const { bbox } = match;
            const x = bbox.x0 / scaleFactor;
            const y = bbox.y0 / scaleFactor;
            const width = (bbox.x1 - bbox.x0) / scaleFactor;
            const height = (bbox.y1 - bbox.y0) / scaleFactor;
            ctx.fillRect(x, y, width, height);
        });
        
        ctx.restore();
    }

  }, [page, selectedPageIndex, viewTransform, currentSearchResult]);
  
  // Effect to handle loading new images and resizing the canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const handleResize = () => {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        resetView();
    };
    
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    if (page) {
        const image = new Image();
        image.crossOrigin = "anonymous";
        image.src = page.originalSrc;
        imageRef.current = image;

        image.onload = handleResize; // This will call resetView
    } else {
        imageRef.current = null;
        handleResize(); // This will clear the canvas
    }
    
    return () => { 
        if(container) resizeObserver.unobserve(container);
    };
    // FIX: Depend on `page.originalSrc` instead of the whole `page` object.
    // This ensures this effect ONLY runs when a new image is selected, not when filters change, preserving manual zoom.
  }, [page?.originalSrc, resetView]);

  // Effect to redraw the canvas whenever the draw function or its dependencies change (e.g., filters, zoom)
  useEffect(() => {
    draw();
  }, [draw]);
  
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!page) return;
    const p = getCanvasPoint(e);
    setIsPanning(true);
    setPanStart({
        x: p.x - viewTransform.pan.x,
        y: p.y - viewTransform.pan.y
    });
    (e.currentTarget as HTMLElement).style.cursor = 'grabbing';
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
        const p = getCanvasPoint(e);
        setViewTransform(v => ({ ...v, pan: { x: p.x - panStart.x, y: p.y - panStart.y } }));
    }
  };
  
  const handleMouseUpOrLeave = (e: React.MouseEvent) => {
    if (!page) return;
    setIsPanning(false);
    (e.currentTarget as HTMLElement).style.cursor = 'grab';
  };
  
  const handleWheel = (e: React.WheelEvent) => {
    if (!page) return;
    e.preventDefault();
    const p = getCanvasPoint(e as unknown as React.MouseEvent);
    const zoomFactor = 1.1;
    const newZoom = e.deltaY < 0 ? viewTransform.zoom * zoomFactor : viewTransform.zoom / zoomFactor;
    
    const imageP = canvasToImagePoint(p);
    const newPan = {
        x: p.x - imageP.x * newZoom,
        y: p.y - imageP.y * newZoom,
    };
    setViewTransform({ zoom: newZoom, pan: newPan });
  };
  
  const zoomBy = (factor: number) => {
    const canvas = canvasRef.current!;
    const center = { x: canvas.width / 2, y: canvas.height / 2 };
    const imageP = canvasToImagePoint(center);
    const newZoom = viewTransform.zoom * factor;
    const newPan = {
        x: center.x - imageP.x * newZoom,
        y: center.y - imageP.y * newZoom,
    };
    setViewTransform({ zoom: newZoom, pan: newPan });
  };

  return (
    <main className="flex-1 bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden">
        <div 
            ref={containerRef} 
            className={`w-full h-full ${page ? 'cursor-grab' : ''}`}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUpOrLeave}
            onMouseLeave={handleMouseUpOrLeave}
            onWheel={handleWheel}
        >
            <canvas ref={canvasRef} />
        </div>
        {!page && (
             <div className="text-slate-500 text-center p-8 absolute">
                <h2 className="text-xl font-bold mb-2">No page selected</h2>
                <p>Select a page from the left panel to view and edit it here.</p>
            </div>
        )}
       
       {page && (
            <div className="absolute bottom-4 right-4 bg-slate-800/80 backdrop-blur-sm p-1 rounded-lg flex items-center gap-1 shadow-lg border border-slate-700">
                <button onClick={() => zoomBy(1/1.2)} className="p-2 rounded hover:bg-slate-700" title="Zoom Out"><ZoomOutIcon /></button>
                <span className="w-16 text-center text-sm font-mono select-none">{Math.round(viewTransform.zoom * 100)}%</span>
                <button onClick={() => zoomBy(1.2)} className="p-2 rounded hover:bg-slate-700" title="Zoom In"><ZoomInIcon /></button>
                <div className="border-l border-slate-600 h-6 mx-1"></div>
                <button onClick={resetView} className="p-2 rounded hover:bg-slate-700" title="Fit to view"><ResetZoomIcon /></button>
            </div>
       )}
    </main>
  );
};

export default EditorPanel;