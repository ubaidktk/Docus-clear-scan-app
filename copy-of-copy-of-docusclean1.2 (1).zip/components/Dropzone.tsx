
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './Icons';

interface DropzoneProps {
  onFilesAdded: (files: File[]) => void;
}

const Dropzone: React.FC<DropzoneProps> = ({ onFilesAdded }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesAdded(Array.from(e.dataTransfer.files));
    }
  }, [onFilesAdded]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesAdded(Array.from(e.target.files));
    }
  };

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={`w-full max-w-xl p-8 border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors duration-300 ${
        isDragging ? 'border-indigo-500 bg-slate-700' : 'border-slate-600 hover:border-slate-500'
      }`}
    >
      <input
        id="file-upload"
        type="file"
        multiple
        accept="image/jpeg, image/png"
        onChange={handleFileChange}
        className="hidden"
      />
      <label htmlFor="file-upload" className="flex flex-col items-center gap-4 cursor-pointer">
        <UploadIcon />
        <p className="text-lg font-semibold text-slate-300">
          Drag & drop files here, or click to select files
        </p>
        <p className="text-sm text-slate-400">Supports JPG and PNG</p>
      </label>
    </div>
  );
};

export default Dropzone;
