import React from 'react';

// FIX: Explicitly typed iconProps to prevent TypeScript from inferring 'string' for props that require a specific set of values (e.g. "round").
const iconProps: React.SVGProps<SVGSVGElement> = {
  className: "w-5 h-5",
  strokeWidth: 2,
  stroke: "currentColor",
  fill: "none",
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

export const LogoIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <path d="m10 14 2 2 4-4"></path>
    </svg>
);
export const FolderIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>;
export const UploadIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>;
export const WebcamIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>;
export const DeleteIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>;
export const RotateIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M23 4v6h-6"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>;
export const BrightnessIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>;
export const ContrastIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 18a6 6 0 0 0 0-12v12z"/></svg>;
export const GrayscaleIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 18a6 6 0 0 0 0-12V6a6 6 0 1 1 0 12z"/></svg>;
export const OcrIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M2 11h5M2 17h5M2 5h5M7 5v14M12 5v14M11 5h2M11 11h2M11 17h2M16 5h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-1M16 13h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-1"/></svg>;
export const CopyIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>;
export const ExportPdfIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M10 18H7a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3v4zM16 18h-3v-4h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zM11.5 14h-1v4"/></svg>;
export const ExportImageIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>;
export const ExportTxtIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>;
export const ZoomInIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>;
export const ZoomOutIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/></svg>;
export const ResetZoomIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/><path d="M12 8v4l2 2"/></svg>;
export const CheckIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>;
export const UndoIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21 13v-2a4 4 0 0 0-4-4H8l-1-1-2 3 2 3 1-1h9a2 2 0 0 1 2 2v2Z"/></svg>;
export const RedoIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 13v-2a4 4 0 0 1 4-4h9l1-1 2 3-2 3-1-1H7a2 2 0 0 0-2 2v2Z"/></svg>;
export const PrintIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>;
export const DuplicateIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>;
export const SharpenIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>;
export const AutoFixIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="m12.1 4.1 1.1-1.1 4.7 4.7-1.1 1.1-4.7-4.7Z"/><path d="M3.6 13.1a2.2 2.2 0 0 0-3 2.8 2.2 2.2 0 0 0 2.8-3l-2-2-2.8 3a2.2 2.2 0 0 0 3 2.8l2-2Z"/><path d="M13 3.6a2.2 2.2 0 0 0 2.8-3 2.2 2.2 0 0 0-3 2.8l2 2 3-2.8a2.2 2.2 0 0 0-2.8-3l-2 2Z"/><path d="m5 12.8 2.8-2.8 4.7 4.7-2.8 2.8-4.7-4.7Z"/><path d="m16.6 6.8 2.8-2.8 4.7 4.7-2.8 2.8-4.7-4.7Z"/><path d="M18 13.3c.6.6.6 1.5 0 2.1l-2.1 2.1c-.6.6-1.5.6-2.1 0l-2.1-2.1c-.6-.6-.6-1.5 0-2.1l2.1-2.1c.6-.6 1.5-.6 2.1 0l2.1 2.1Z"/></svg>;
export const BwIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><path d="M12 2a10 10 0 1 0 0 20v-20" /></svg>;
export const CropIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M6.13 1L6 16a2 2 0 0 0 2 2h15"/><path d="M1 6.13L16 6a2 2 0 0 1 2 2v15"/></svg>;
export const EraseIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M16.473 6.473 17.527 7.527 12 13.054 6.473 7.527 7.527 6.473 12 12l4.473-5.527Z" /><path d="M21 21H3V6.944l9 11.056 9-11.056V21Z" /></svg>;
export const ChevronDownIcon: React.FC<{className?: string}> = ({className}) => <svg {...iconProps} className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>;
export const SearchIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>;
export const TextEnhanceIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4 7V5h12v2M9 5v14m-2-5h4"/><path d="m18.5 7.5 1-1 1 1-1 1-1-1Z"/><path d="m21.5 10.5 1-1 1 1-1 1-1-1Z"/><path d="m16 5 1-1 1 1-1 1-1-1Z"/></svg>;
export const ShadowRemovalIcon: React.FC = () => <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12.5 2.5.6 6.2l3.2 9.7 7.2 4.6 10-6.2-3.2-9.7Z"/><path d="m6.2 3.5 11.2 6.8-3.5 4.2-11.2-6.8Z"/><path d="M12.5 2.5 6.2 13.3l4.2 2.7 6.3-9.8Z"/></svg>;
export const CloseIcon: React.FC = () => <svg {...iconProps} strokeWidth={3} className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>;
export const MaximizeIcon: React.FC = () => <svg {...iconProps} strokeWidth={3} className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 3h18v18H3z"/></svg>;
export const MinimizeIcon: React.FC = () => <svg {...iconProps} strokeWidth={3} className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 12h14"/></svg>;
