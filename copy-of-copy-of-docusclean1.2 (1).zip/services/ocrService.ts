import { Page, OcrData, OcrWord } from '../types';
import Tesseract from 'tesseract.js';

let worker: Tesseract.Worker | null = null;
let currentLang: string | null = null;

const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
    });
};

const initializeWorker = async (lang: string, progressCallback: (progress: string) => void) => {
    progressCallback('Initializing OCR Engine...');

    if (worker && currentLang !== lang) {
        progressCallback('Switching OCR language...');
        await worker.terminate();
        worker = null;
        currentLang = null;
    }

    if (!worker) {
        const langPath = await window.electronAPI.getTessdataLangPath();
        
        worker = await Tesseract.createWorker(lang, 1, {
            langPath,
            logger: (m: Tesseract.LoggerMessage) => {
                if (m.status === 'recognizing text') {
                    progressCallback(`Recognizing... ${Math.round(m.progress * 100)}%`);
                }
            },
        });
        currentLang = lang;
    }
    return worker;
};

const deskewImage = (canvas: HTMLCanvasElement): number => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return 0;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    const width = canvas.width;
    const height = canvas.height;
    
    const angleRange = 5;
    const angleStep = 0.2;
    let bestAngle = 0;
    let maxVariance = 0;

    for (let angle = -angleRange; angle <= angleRange; angle += angleStep) {
        const radians = angle * (Math.PI / 180);
        const cos = Math.cos(radians);
        const sin = Math.sin(radians);
        const histogram = new Array(height).fill(0);

        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const i = (y * width + x) * 4;
                if (data[i] < 128) {
                    const newY = Math.round(x * sin + y * cos);
                    if (newY >= 0 && newY < height) {
                        histogram[newY]++;
                    }
                }
            }
        }
        
        const mean = histogram.reduce((a, b) => a + b, 0) / histogram.length;
        const variance = histogram.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / histogram.length;

        if (variance > maxVariance) {
            maxVariance = variance;
            bestAngle = angle;
        }
    }
    return bestAngle;
};

const applyAdaptiveThreshold = (ctx: CanvasRenderingContext2D) => {
    const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
    const data = imageData.data;
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    const s = width / 8;
    const t = 0.15;
    const integralImage = new Uint32Array(width * height);
    
    for (let y = 0; y < height; y++) {
        let rowSum = 0;
        for (let x = 0; x < width; x++) {
            const i = (y * width + x) * 4;
            const luma = data[i] * 0.299 + data[i+1] * 0.587 + data[i+2] * 0.114;
            rowSum += Math.round(luma);
            if (y === 0) {
                integralImage[y * width + x] = rowSum;
            } else {
                integralImage[y * width + x] = integralImage[(y - 1) * width + x] + rowSum;
            }
        }
    }

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const i = (y * width + x) * 4;
            const luma = data[i] * 0.299 + data[i+1] * 0.587 + data[i+2] * 0.114;

            const x1 = Math.max(0, x - Math.floor(s / 2));
            const y1 = Math.max(0, y - Math.floor(s / 2));
            const x2 = Math.min(width - 1, x + Math.floor(s / 2));
            const y2 = Math.min(height - 1, y + Math.floor(s / 2));

            const count = (x2 - x1) * (y2 - y1);
            const sum = integralImage[y2 * width + x2] - integralImage[y1 * width + x2] - integralImage[y2 * width + x1] + integralImage[y1 * width + x1];

            const avg = sum / count;
            const color = luma < avg * (1 - t) ? 0 : 255;
            data[i] = data[i+1] = data[i+2] = color;
        }
    }
    ctx.putImageData(imageData, 0, 0);
};

const clamp = (value: number) => Math.max(0, Math.min(255, value));

const applyConvolution = (ctx: CanvasRenderingContext2D, kernel: number[][]) => {
    const canvas = ctx.canvas;
    const srcData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const src = srcData.data;
    const dstData = ctx.createImageData(canvas.width, canvas.height);
    const dst = dstData.data;
    const width = canvas.width;
    const height = canvas.height;
    const kernelSize = kernel.length;
    const halfKernel = Math.floor(kernelSize / 2);

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const dstOff = (y * width + x) * 4;
            let r = 0, g = 0, b = 0;

            for (let ky = 0; ky < kernelSize; ky++) {
                for (let kx = 0; kx < kernelSize; kx++) {
                    const sy = y + ky - halfKernel;
                    const sx = x + kx - halfKernel;

                    if (sy >= 0 && sy < height && sx >= 0 && sx < width) {
                        const srcOff = (sy * width + sx) * 4;
                        const weight = kernel[ky][kx];
                        r += src[srcOff] * weight;
                        g += src[srcOff + 1] * weight;
                        b += src[srcOff + 2] * weight;
                    }
                }
            }
            dst[dstOff] = clamp(r);
            dst[dstOff + 1] = clamp(g);
            dst[dstOff + 2] = clamp(b);
            dst[dstOff + 3] = src[dstOff + 3];
        }
    }
    ctx.putImageData(dstData, 0, 0);
};


export const extractTextFromImageLocal = async (page: Page, language: string, progressCallback: (progress: string) => void): Promise<OcrData> => {
    try {
        progressCallback('Preparing image...');
        const img = await loadImage(page.originalSrc);
        const canvas = document.createElement('canvas');
        
        const SCALE_FACTOR = 2.0;
        canvas.width = img.naturalWidth * SCALE_FACTOR;
        canvas.height = img.naturalHeight * SCALE_FACTOR;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) throw new Error('Could not get canvas context');

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        if (language === 'urd') {
            progressCallback('Preprocessing (Sharpening)...');
            // FIX: Use a refined sharpening kernel for better character definition in Urdu script.
            const sharpenKernel = [[0, -1, 0], [-1, 5, -1], [0, -1, 0]];
            applyConvolution(ctx, sharpenKernel);
        }
        
        progressCallback('Preprocessing (Binarizing)...');
        applyAdaptiveThreshold(ctx);

        progressCallback('Preprocessing (Deskewing)...');
        const skewAngle = deskewImage(canvas);
        if (Math.abs(skewAngle) > 0.1) {
            const tempCanvas = document.createElement('canvas');
            const tempCtx = tempCanvas.getContext('2d');
            if(tempCtx) {
                tempCanvas.width = canvas.width;
                tempCanvas.height = canvas.height;
                tempCtx.translate(canvas.width / 2, canvas.height / 2);
                tempCtx.rotate(skewAngle * (Math.PI / 180));
                tempCtx.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(tempCanvas, 0, 0);
            }
        }

        const ocrWorker = await initializeWorker(language, progressCallback);
        const result = await ocrWorker.recognize(canvas);
        const { data } = result;
        
        const words: OcrWord[] = data.words.map(w => ({
            text: w.text,
            bbox: {
                x0: w.bbox.x0,
                y0: w.bbox.y0,
                x1: w.bbox.x1,
                y1: w.bbox.y1,
            }
        }));

        return {
            text: data.text,
            words: words,
            scaleFactor: SCALE_FACTOR,
        };
    } catch (error) {
        console.error("Error performing local OCR:", error);
        throw new Error("Local OCR failed to extract text.");
    }
};

window.addEventListener('beforeunload', () => {
    if (worker) {
      worker.terminate();
      worker = null;
      currentLang = null;
    }
});