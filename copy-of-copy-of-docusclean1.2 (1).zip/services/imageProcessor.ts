import { Page, FilterSettings } from '../types';

// Helper to load an image from a data URL
const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
    });
};

const clamp = (value: number) => Math.max(0, Math.min(255, value));

// Applies a convolution matrix (kernel) to image data, used for sharpening
const applyConvolution = (ctx: CanvasRenderingContext2D, kernel: number[][]) => {
    const canvas = ctx.canvas;
    const srcData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const src = srcData.data;
    const dstData = ctx.createImageData(canvas.width, canvas.height);
    const dst = dstData.data;
    const width = canvas.width;
    const height = canvas.height;
    const kernelSize = kernel.length;
    const halfKernel = Math.floor(kernelSize / 2);

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const dstOff = (y * width + x) * 4;
            let r = 0, g = 0, b = 0;

            for (let ky = 0; ky < kernelSize; ky++) {
                for (let kx = 0; kx < kernelSize; kx++) {
                    const sy = y + ky - halfKernel;
                    const sx = x + kx - halfKernel;

                    if (sy >= 0 && sy < height && sx >= 0 && sx < width) {
                        const srcOff = (sy * width + sx) * 4;
                        const weight = kernel[ky][kx];
                        r += src[srcOff] * weight;
                        g += src[srcOff + 1] * weight;
                        b += src[srcOff + 2] * weight;
                    }
                }
            }
            dst[dstOff] = clamp(r);
            dst[dstOff + 1] = clamp(g);
            dst[dstOff + 2] = clamp(b);
            dst[dstOff + 3] = src[dstOff + 3]; // Keep original alpha
        }
    }
    ctx.putImageData(dstData, 0, 0);
};

export const getFilteredImageData = async (pageToProcess: Page, isBwThreshold = false): Promise<string> => {
    const img = await loadImage(pageToProcess.originalSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');

    // This function is now simplified as destructive edits handle rotation and presets.
    // It only applies non-destructive preview filters.
    const { brightness, contrast, grayscale } = pageToProcess.filterSettings;
    
    canvas.width = img.width;
    canvas.height = img.height;

    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) grayscale(${grayscale}%)`;

    ctx.drawImage(img, 0, 0);
    
    // Note: Sharpen is a destructive action and applied via presets/baking now.
    // We don't apply it in this preview function for performance reasons.
    
    if (isBwThreshold) {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
            const color = avg > 128 ? 255 : 0;
            data[i] = color;
            data[i + 1] = color;
            data[i + 2] = color;
        }
        ctx.putImageData(imageData, 0, 0);
    }
    
    return canvas.toDataURL('image/jpeg', 0.95);
};

export const applyRotation = async (src: string, angle: 90 | 180 | 270): Promise<string> => {
    const img = await loadImage(src);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');

    if (angle === 90 || angle === 270) {
        canvas.width = img.height;
        canvas.height = img.width;
    } else {
        canvas.width = img.width;
        canvas.height = img.height;
    }

    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(angle * Math.PI / 180);
    ctx.drawImage(img, -img.width / 2, -img.height / 2);
    
    return canvas.toDataURL('image/jpeg', 0.95);
}

export const applySharpen = async (src: string): Promise<string> => {
    const img = await loadImage(src);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');
    
    ctx.drawImage(img, 0, 0);

    const sharpenKernel = [[0, -1, 0], [-1, 5, -1], [0, -1, 0]];
    applyConvolution(ctx, sharpenKernel);
    
    return canvas.toDataURL('image/jpeg', 0.95);
};


export const applyPreset = async (src: string, preset: 'auto-enhance' | 'bw' | 'text-enhance' | 'shadow-remove'): Promise<string> => {
    const img = await loadImage(src);
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');
    
    ctx.drawImage(img, 0, 0);

    if (preset === 'auto-enhance') {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        const histogram = new Array(256).fill(0);

        for (let i = 0; i < data.length; i += 4) {
            const luma = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
            histogram[Math.round(luma)]++;
        }

        const totalPixels = canvas.width * canvas.height;
        const clipThreshold = totalPixels * 0.01;
        let cumulative = 0;
        let min = 0;
        for (let i = 0; i < 256; i++) {
            cumulative += histogram[i];
            if (cumulative > clipThreshold) {
                min = i;
                break;
            }
        }

        cumulative = 0;
        let max = 255;
        for (let i = 255; i >= 0; i--) {
            cumulative += histogram[i];
            if (cumulative > clipThreshold) {
                max = i;
                break;
            }
        }

        if (max <= min) {
            max = 255; min = 0;
        }

        const range = max - min;
        for (let i = 0; i < data.length; i += 4) {
            data[i] = clamp((data[i] - min) * 255 / range);
            data[i + 1] = clamp((data[i + 1] - min) * 255 / range);
            data[i + 2] = clamp((data[i + 2] - min) * 255 / range);
        }
        ctx.putImageData(imageData, 0, 0);

        const sharpenKernel = [[0, -1, 0], [-1, 5, -1], [0, -1, 0]];
        applyConvolution(ctx, sharpenKernel);

    } else if (preset === 'bw') {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
            const color = avg > 128 ? 255 : 0;
            data[i] = data[i + 1] = data[i + 2] = color;
        }
        ctx.putImageData(imageData, 0, 0);

    } else if (preset === 'text-enhance') {
        const textSharpenKernel = [[ -1, -1, -1 ], [ -1,  9, -1 ], [ -1, -1, -1 ]];
        applyConvolution(ctx, textSharpenKernel);

    } else if (preset === 'shadow-remove') {
        // Create a blurred background canvas to map the illumination
        const bgCanvas = document.createElement('canvas');
        bgCanvas.width = canvas.width;
        bgCanvas.height = canvas.height;
        const bgCtx = bgCanvas.getContext('2d');
        if (!bgCtx) return src;
        
        bgCtx.filter = 'blur(50px) grayscale(1)';
        bgCtx.drawImage(canvas, 0, 0);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        const bgData = bgCtx.getImageData(0, 0, canvas.width, canvas.height).data;

        for (let i = 0; i < data.length; i += 4) {
            const bgLuma = (bgData[i] + bgData[i+1] + bgData[i+2]) / 3;
            const correction = 255 / (bgLuma + 1); // +1 to avoid division by zero
            data[i] = clamp(data[i] * correction);
            data[i + 1] = clamp(data[i + 1] * correction);
            data[i + 2] = clamp(data[i + 2] * correction);
        }
        ctx.putImageData(imageData, 0, 0);
    }
    
    return canvas.toDataURL('image/jpeg', 0.95);
};
