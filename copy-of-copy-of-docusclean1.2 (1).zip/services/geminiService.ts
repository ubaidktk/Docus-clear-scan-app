// This file is no longer in use as the application has been converted to a 100% offline-first architecture.
// All online API dependencies, including Gemini, have been removed.
