import { Page } from '../types';

const RECENTS_KEY = 'docuCleanRecents';
const DOC_PREFIX = 'docuCleanDoc-';

const getTodayKey = (): string => {
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const saveDocument = (pages: Page[]): void => {
    if (!pages || pages.length === 0) return;
    
    try {
        const todayKey = getTodayKey();
        const docKey = `${DOC_PREFIX}${todayKey}`;
        
        // Don't save transient state
        const pagesToSave = pages.map(({ isSelected, isIndexing, ...rest }) => rest);
        localStorage.setItem(docKey, JSON.stringify(pagesToSave));

        // Update recents list
        const recents = getRecentDocuments();
        const existingRecent = recents.find(r => r.key === todayKey);
        
        if (existingRecent) {
            existingRecent.pageCount = pages.length;
            existingRecent.lastModified = new Date().toISOString();
        } else {
            recents.unshift({
                key: todayKey,
                name: `Session - ${todayKey}`,
                pageCount: pages.length,
                lastModified: new Date().toISOString()
            });
        }
        
        // Keep recents list to a reasonable size, e.g., 20
        const sortedRecents = recents.sort((a, b) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime());
        localStorage.setItem(RECENTS_KEY, JSON.stringify(sortedRecents.slice(0, 20)));

    } catch (error) {
        console.error("Failed to save document to localStorage:", error);
    }
};

export const loadDocument = (dateKey: string): Page[] | null => {
    try {
        const docKey = `${DOC_PREFIX}${dateKey}`;
        const savedData = localStorage.getItem(docKey);
        if (savedData) {
            return JSON.parse(savedData) as Page[];
        }
        return null;
    } catch (error) {
        console.error(`Failed to load document ${dateKey} from localStorage:`, error);
        return null;
    }
};

export interface RecentDocument {
    key: string;
    name: string;
    pageCount: number;
    lastModified: string;
}

export const getRecentDocuments = (): RecentDocument[] => {
    try {
        const recentsData = localStorage.getItem(RECENTS_KEY);
        return recentsData ? JSON.parse(recentsData) : [];
    } catch (error) {
        console.error("Failed to get recent documents from localStorage:", error);
        return [];
    }
};

export const deleteDocument = (dateKey: string): void => {
    try {
        // Remove document
        localStorage.removeItem(`${DOC_PREFIX}${dateKey}`);
        
        // Remove from recents
        let recents = getRecentDocuments();
        recents = recents.filter(r => r.key !== dateKey);
        localStorage.setItem(RECENTS_KEY, JSON.stringify(recents));
    } catch (error) {
        console.error(`Failed to delete document ${dateKey}:`, error);
    }
}
