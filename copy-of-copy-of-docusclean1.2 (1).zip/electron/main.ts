import { app, BrowserWindow, ipcMain } from 'electron';
import path from 'path';

// FIX: Added declaration for `__dirname` to resolve "Cannot find name '__dirname'" error
// on lines 12 and 21. This provides the necessary type for the Node.js global.
declare const __dirname: string;

// FIX: Added declaration for `process` to resolve errors for properties `cwd`, `resourcesPath`,
// and `platform` on lines 40, 43, and 57 respectively. This provides the necessary types.
declare const process: {
  cwd: () => string;
  resourcesPath: string;
  platform: string;
};

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 940,
    minHeight: 600,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    backgroundColor: '#1e293b',
    show: false,
  });

  // This is the key change: always load the local file from the 'dist' directory.
  mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));

  mainWindow.on('ready-to-show', () => {
    mainWindow.show();
  });

  // --- IPC Handlers ---
  ipcMain.on('minimize-window', () => mainWindow.minimize());
  ipcMain.on('maximize-window', () => {
    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize();
    } else {
      mainWindow.maximize();
    }
  });
  ipcMain.on('close-window', () => mainWindow.close());

  ipcMain.handle('get-tessdata-lang-path', () => {
    // In development, we look for the folder relative to the project root.
    const devPath = path.resolve(process.cwd(), 'public', 'tessdata');
    
    // In production, `extraResources` in package.json copies it to the `resources` directory.
    const prodPath = path.resolve(process.resourcesPath, 'tessdata');

    return app.isPackaged ? prodPath : devPath;
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});